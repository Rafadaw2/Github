/*
Con esta url obtenemos el numero de peliculas.
http://localhost:3000/numeroPelis

Con esta url http://localhost:3000/peli1 obtenemos la pelicula1

*/

function obtenerDatos(url, callback) {
    fetch(url)
        .then((respuesta) => {
            if (!respuesta.ok) {
                return callback(`Error HTTP ${respuesta.status}`, null);
            }
            return respuesta.json().then((datos) => callback(null, datos));
        })
        .catch((error) => callback(`Error de red: ${error.message}`, null)); // Captura errores de conexión
}

function recogerDatos(error = null, datos = null) {
    if (error !== null) {
        console.log(error); // Muestra el error en consola
    } else {
        console.table(datos); // Muestra los datos si no hubo error
    }
}

obtenerDatos("http://localhost:3000/peli1", recogerDatos);


