let inventario=[
    {
        "url_imagen": "https://images.unsplash.com/photo-1517430816045-df4b7de11d1e",
        "descripcion": "Laptop de última generación",
        "precio": 899.99,
        "descuento": "black friday"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1593642634367-d91a135587b5",
        "descripcion": "Televisor 4K UHD 55 pulgadas",
        "precio": 499.99,
        "descuento": "black friday"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1519183071298-a2962eade1b0",
        "descripcion": "Cámara fotográfica profesional",
        "precio": 1200.00,
        "descuento": "black friday"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1512499617640-c2f999018b72",
        "descripcion": "Auriculares inalámbricos",
        "precio": 199.99,
        "descuento": "black friday"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9",
        "descripcion": "Smartphone gama alta",
        "precio": 1099.00,
        "descuento": "black friday"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1606813901444-1f7e91dcd5f3",
        "descripcion": "Zapatillas deportivas",
        "precio": 120.00,
        "descuento": "normal"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1516574187841-cb9cc2ca948b",
        "descripcion": "Reloj inteligente",
        "precio": 299.99,
        "descuento": "normal"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
        "descripcion": "Teclado mecánico RGB",
        "precio": 80.00,
        "descuento": "normal"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
        "descripcion": "Ratón gaming",
        "precio": 59.99,
        "descuento": "normal"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f",
        "descripcion": "Mochila impermeable",
        "precio": 49.99,
        "descuento": "normal"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
        "descripcion": "Monitor Full HD 24 pulgadas",
        "precio": 150.00,
        "descuento": "sin descuento"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
        "descripcion": "Micrófono profesional",
        "precio": 120.00,
        "descuento": "sin descuento"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
        "descripcion": "Silla ergonómica de oficina",
        "precio": 180.00,
        "descuento": "sin descuento"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
        "descripcion": "Luz de anillo LED",
        "precio": 45.00,
        "descuento": "sin descuento"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
        "descripcion": "Parlantes Bluetooth portátiles",
        "precio": 89.99,
        "descuento": "sin descuento"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
        "descripcion": "Tablet multimedia",
        "precio": 350.00,
        "descuento": "sin descuento"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
        "descripcion": "Gafas de realidad virtual",
        "precio": 399.99,
        "descuento": "sin descuento"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
        "descripcion": "Fuente de alimentación 650W",
        "precio": 75.00,
        "descuento": "sin descuento"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
        "descripcion": "Disco duro externo 1TB",
        "precio": 120.00,
        "descuento": "sin descuento"
    },
    {
        "url_imagen": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
        "descripcion": "Placa base para gaming",
        "precio": 210.00,
        "descuento": "sin descuento"
    }
]
