import './style.css'
//Debemos importar el fichero para que se vea
//import './ejemplosTS/01-tipos-basicos.ts'
//import './ejemplosTS/02-objetos-arrays-interfaces'
//import './ejemplosTS/03-funciones'
//import './ejemplosTS/04-objetos-funciones'
// import './ejemplosTS/05-clases' 


document.querySelector<HTMLDivElement>('#app')!.innerHTML = `
 <h1>Mini curso de typescript</h1>
`


