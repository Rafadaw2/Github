<?php
// Imports completar
class AvistamientosController {
    private $modelo;
    private $vistaImpacto;
    private $vistaResultadoBusqueda;

    
    public function __construct() {
       //Completar
    }

    public function buscar($nombreMeteorito) {
        
        // 1 Obtener resultados desde el modelo 
       

        // 2 Mostrar la vista con los resultados
    
       
    }
    public function obtenerImpacto($tam,$velocidad){
        //Completar

    }
}
