<?php

class MeteoritoModel {
    private string $name;
    private string $closeApproachDate;
    private string $tamano;
    private string $velocidad;

    // Constructor para inicializar los atributos
    public function __construct(string $name, string $closeApproachDate, string $tamano, string $velocidad) {
       
    }

    // Métodos getter
    public function getName(): string {
      
    }

    public function getCloseApproachDate(): string {
        
    }

    public function getTamano(): string {
        
    }

    public function getVelocidad(): string {
        
    }
}
